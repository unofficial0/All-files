﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
   
        public delegate double ConvertToCelsius(double fahrenheit);

        public class Program
        {
            static void Main(string[] args)
            {
            ///Using Anonymous Method
            ConvertToCelsius celsiusobj1 = delegate (double fahrenheit)
                {
                    Console.WriteLine("fahrenheit");
                    return ((fahrenheit - 32 / 1.8));
                };
              celsiusobj1(32);

           ///Using Lambda Expression
            ConvertToCelsius celsiusobj2= (fahrenheit) => { Console.WriteLine("fahrenheit {0}", (fahrenheit - 32 / 1.8)); };
            celsiusobj2(32);

                Console.ReadKey();
            }
        }
    
}
