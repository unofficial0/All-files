﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEvents_Demo
{
    delegate void BankAccountDelegate(double ob, double nb);
    class BankAccount
    {
        public event BankAccountDelegate BalanceChanged = null; //field
        public int AccNo { get; set; }
        public double Balance { get; set; }

        public BankAccount(int accNo, double balance)
        {
            this.AccNo = accNo;
            this.Balance = balance;            
        }

        public void With(double amt)
        {
            if (Balance >= amt)
            {
                double oBal = Balance;
                Balance -= amt;
                if (BalanceChanged != null)
                    BalanceChanged(oBal, Balance);
            }
        }

        public void Depo(double amt)
        {
            double oBal = Balance;
            Balance += amt;
            if (BalanceChanged != null)
                BalanceChanged(oBal, Balance);
        }
    }
}
