﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEvents_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Notifications noti = new Notifications();

            //BankAccountDelegate del1 = null;
            //del1 = new BankAccountDelegate(noti.SendSMS);
            //del1 += new BankAccountDelegate(noti.SendMail);

            BankAccount bankAccount = new BankAccount(101, 5000);
            bankAccount.BalanceChanged += new BankAccountDelegate(noti.SendMail);
            bankAccount.With(1000);
            Console.WriteLine(bankAccount.Balance);            

            Console.ReadKey();

        }

    }
}
