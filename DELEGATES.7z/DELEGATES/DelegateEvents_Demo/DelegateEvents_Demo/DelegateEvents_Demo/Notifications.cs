﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEvents_Demo
{
    class Notifications
    {      

        public void SendMail(double oBalance, double nBalance)
        {
            Console.WriteLine("Mail: Balance getting changed from "+oBalance+" to "+nBalance);
        }

        public void SendSMS(double oBalance, double nBalance)
        {
            Console.WriteLine("SMS: Balance getting changed from " + oBalance + " to " + nBalance);
        }
    }
}
