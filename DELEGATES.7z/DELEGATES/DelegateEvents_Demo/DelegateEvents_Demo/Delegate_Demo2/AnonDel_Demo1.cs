﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demo2.AnonDel
{

    // n1 + n2

    // Calc.Add(n1, n2)
    // Calc obj = new Calc();  obj.Add(n1, n2);


    delegate int CalcDelegate(int n1, int n2);
    //class Calc
    //{
    //    public static int Add(int n1, int n2)
    //    {
    //        return (n1 + n2);
    //    }
    //    public static int Sub(int n1, int n2)
    //    {
    //        return n1 - n2;
    //    }
    //    public static int Mult(int n1, int n2)
    //    {
    //        return (n1 / n2);
    //    }
    //}
    class AnonDel_Demo1
    {
        delegate void D1();
        delegate void D2(string s1);
        delegate string D3();
        delegate string D4(string fn, string ln);

        static void Main(string[] args)
        {
            ////Anonymous/Inline Method/Delegate (C#-2.0)
            ////CalcDelegate del1 = new CalcDelegate(Calc.Add);
            //CalcDelegate del1 = delegate (int n1, int n2) { return n1 + n2; };

            //Lambda Expression (C#-3.0)
            // 1. Expression Lambda  |  2. Multiple Lambda
            CalcDelegate del1 = (n1, n2) => n1 + n2;                        

            Console.WriteLine(del1(3, 2));

            D1 d1 = () => Console.WriteLine("Hello");
            d1();

            D2 d2 = (s1) => Console.WriteLine(s1);
            d2("Hi");

            D3 d3 = () => "Hi";
            Console.WriteLine( d3());

            //Multiple Lambda
            D4 d4 = (fn, ln) => { string fln = fn + " " + ln; return fln; };
            Console.WriteLine( d4("Mahesh", "Kale"));

            Console.ReadKey();
        }
    }
}
