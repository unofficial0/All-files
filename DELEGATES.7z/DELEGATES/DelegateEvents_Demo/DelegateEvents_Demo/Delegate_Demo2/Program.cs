﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demo2.GenericDel
{
    //Demo: Generic Delegate
    delegate RT CalcDelegate<PT,RT>(PT n1, PT n2);

    //delegate string CalcDelegate1(int n1, int n2);
    //delegate int CalcDelegate2(int n1, int n2);
    //delegate string CalcDelegate3(double n1, double n2);
    class Calc
    {
        public static string Add(int n1, int n2)
        {
            return (n1 + n2).ToString();
        }
        public static int Sub(int n1, int n2)
        {
            return n1 - n2;
        }
        public static string Mult(double n1, double n2)
        {
            return (n1 / n2).ToString();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            //CalcDelegate1 d1 = new CalcDelegate1(Calc.Add);
            //CalcDelegate2 d2 = new CalcDelegate2(Calc.Sub);
            //CalcDelegate3 d3 = new CalcDelegate3(Calc.Mult);

            CalcDelegate<int, string> d1 = new CalcDelegate<int, string>(Calc.Add);
            Console.WriteLine(d1);
            CalcDelegate<int, int> d2 = new CalcDelegate<int, int>(Calc.Sub);
            CalcDelegate<double, string> d3 = new CalcDelegate<double, string>(Calc.Mult);

            Console.ReadKey();
        }
    }
}
