﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Program
    {
       

        static void Main(string[] args)
        {

            DivideNum<int> division = new DivideNum<int>();
            division.FirstNumber = 5;
            division.SecondNumber = 6;

            int firstNO = division.FirstNumber;
            int secondNO = division.SecondNumber;
            int result = firstNO + secondNO;
            Console.WriteLine(result);

            Console.ReadKey();

            DivideNum<double> division1 = new DivideNum<double>();
            division1.FirstNumber = 5;
            division1.SecondNumber = 6;

            double firstNO1 = division.FirstNumber;
            double secondNO1 = division.SecondNumber;
            double result1 = firstNO + secondNO;
            Console.WriteLine(result);

             Console.ReadKey();

        }
        /// <summary>
        /// Division class can take any type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public class DivideNum<T>
        {
            private T firstNumber;

            public T FirstNumber
            {
                get { return firstNumber; }
                set { firstNumber = value; }
            }
            private T secondNumber;

            public T SecondNumber
            {
                get { return secondNumber; }
                set { secondNumber = value; }
            }

        }
    }
}
