﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BMS.Entities;//Access to Entities
using BMS.BookException;//Access to Custom Exception

namespace BMS.DAL
{
    public class BookDAL
    {
        private static List<Book> blist = 
            new List<Book>();

        //Adding a Book to Collection
        public bool AddBookDAL(Book book)
        {
            bool bookAdded = false;
            try
            {
                blist.Add(book);
                bookAdded = true;
            }
            catch (BookException.BookException ex)
            {
                throw new 
                    BookException.BookException("Unable to Add book");
            }
            return bookAdded;
        }

        //Updating Book Details
        public bool UpdateBookDAL(Book book)
        {
            bool bookUpdated = false;

            try
            {
                foreach (Book b in blist)
                {
                    if (b.ID == book.ID)
                    {
                        b.Name = book.Name;
                        b.Price = book.Price;
                        b.Description = book.Description;
                        bookUpdated = true;
                        break;
                    }
                }
            }
            catch (BookException.BookException ex)
            {
                throw new 
                    BookException.BookException("Unable to Update Book");
            }

            return bookUpdated;
        }

        public bool DeleteBookDAL(int id)
        {
            Book book = null;
            bool bookDeleted = false;
            try
            {
                foreach (Book b in blist)
                {
                    if (b.ID == id)
                    {
                        book = b;
                        blist.Remove(book);
                        bookDeleted = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new
                       BookException.BookException("Unable to Delete Book");
            }

            return bookDeleted;
        }

        //Searching a Book
        public Book SearchDAL(int id)
        {
            Book book = null;

            foreach (Book b in blist)
            {
                if (b.ID == id)
                {
                    book = b;
                    break;
                }
            }
            return book;
        }

        //Displaying all books
        public List<Book> GetBooksDAL()
        {
            if (blist == null)
            {
                throw new BookException.
                    BookException("List is Empty");
            }
            else
                return blist;
        }
    }
}
