﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.BookException;
using BMS.DAL;
using BMS.Entities;

namespace BMS.BLL
{
    public class BookBLL
    {
        private static bool Validate(Book book)
        {
            StringBuilder sb = new StringBuilder();
            bool validBook = true;
            if (book.ID <= 0)
            {
                validBook = false;
                sb.Append("\nId cannot be zero or negative");
            }

            if (book.Name == string.Empty)
            {
                validBook = false;
                sb.Append("\nBook name cannot be blank");
            }

            if (book.Price <= 0)
            {
                validBook = false;
                sb.Append("\nPrice cannot be zero or negative");
            }

            if (book.Description == string.Empty)
            {
                validBook = false;
                sb.Append("\nDescription cannot be blank");
            }

            if (validBook == false)
                throw new BookException.
                    BookException(sb.ToString());

            return validBook;
        }

        public static bool AddBookBLL(Book book)
        {
            bool bookAdded = false;
            try
            {
                if (Validate(book))
                {
                    BookDAL obj = new BookDAL();
                    bookAdded = obj.AddBookDAL(book);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bookAdded;
        }

        public static bool UpdateBookBLL(Book book)
        {
            bool bookUpdated = false;
            try
            {
                if (Validate(book))
                {
                    BookDAL obj = new BookDAL();
                    bookUpdated = obj.UpdateBookDAL(book);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bookUpdated;
        }

        public static bool DeleteBookBLL(int id)
        {
            bool bookDeleted = false;
            try
            {
                BookDAL obj = new BookDAL();
                bookDeleted = obj.DeleteBookDAL(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bookDeleted;
        }

        public static Book SearchBLL(int id)
        {
            Book book = null;
            try
            {
                BookDAL obj = new BookDAL();
                book = obj.SearchDAL(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return book;
        }

        public static List<Book> GetBooksBLL()
        {
            List<Book> blist=null;
            try
            {
                BookDAL obj = new BookDAL();
                blist = obj.GetBooksDAL();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return blist;
        }
    }
}
