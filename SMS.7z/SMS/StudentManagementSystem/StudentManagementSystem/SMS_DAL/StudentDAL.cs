﻿using SMS_Entities;
using SMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SMS_DAL
{
   
    public class StudentDAL
    {
        public static List<Student> studs = new List<Student>();

        public bool AddStudentDAL(Student student)
        {
            bool studentAdded = false;
            try
            {
                studs.Add(student);
                studentAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            } 
            return studentAdded;

        }

        //public static List<Student> ReturnStudentInformation()
        //{
        //    return studs;
        //}
        public Student SearchStudentDAL(int rollNo)
        {

            try
            {
                Student searchStudent = null;
                foreach (var student in studs)
                {
                    if (student.RollNo == rollNo)
                    {
                        searchStudent = student;
                    }

                }
                return searchStudent;
            }
            catch (Exception e)
            {
                throw e;
            }
            
        }

        public bool UpdateStudentDAL(Student student)
        {
            bool studentUpdated = true;
            try
            {
                for (int i = 0; i < studs.Count; i++)
                {
                    if(studs[i].RollNo==student.RollNo)
                    {
                        studs[i].StudName = student.StudName;
                        studs[i].DOB = student.DOB;
                        studs[i].MobileNo = student.MobileNo;
                        studs[i].FeesPaid = student.FeesPaid;
                        break;
                    }
                }

                //var stud = studs.Find(s => s.RollNo == student.RollNo);
                //if (stud != null)
                //{
                //    stud.StudName = student.StudName;
                //    stud.RollNo = student.RollNo;
                //    stud.MobileNo = student.MobileNo;
                //    stud.FeesPaid = student.FeesPaid;
                //    stud.DOB = student.DOB;
                //    studentUpdated = true;
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentUpdated;
        }

        public  bool DeleteStudentDAL(int rollNo)
        {
            bool studentDeleted = false;
            try
            {
                Student student = studs.Find(s => s.RollNo == rollNo);                
                studs.Remove(student);
                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return studentDeleted;



        }

        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"Student.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, studs);
                stream.Close();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public static List<Student> DeserializeData()
        {
            FileStream stream = new FileStream(@"Student.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            studs=formatter.Deserialize(stream) as List<Student>;
            return studs;
        }

        //public bool DeleteStudentDAL(int deleteStudentID)
        //{
        //    throw new NotImplementedException();
        //}



        
    }
}



