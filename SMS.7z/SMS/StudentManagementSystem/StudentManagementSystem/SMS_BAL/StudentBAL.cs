﻿using SMS_DAL;
using SMS_Entities;
using SMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_BAL
{
    public class StudentBAL
    {
        public static List<Student> stud = new List<Student>();
        public static object studs;
        private static bool ValidateStudent(Student student)
        {
            StringBuilder sb = new StringBuilder();
            bool validStudent = true;
            if (student.RollNo <= 0)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Invalid student ID");

            }
            if (student.StudName == string.Empty)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "student Name Required");

            }
            if (student.MobileNo.Length != 10)
            {
                validStudent = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validStudent == false)
                throw new StudentNotFoundException(sb.ToString());
            return validStudent;
        }

        public static bool AddStudentBAL(Student newStudent)
        {
            bool studentAdded = false;
            try
            {
                if (ValidateStudent(newStudent))
                {
                    StudentDAL studentDAL = new StudentDAL();
                    studentAdded = studentDAL.AddStudentDAL(newStudent);
                }
            }
            catch (StudentNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studentAdded;
        }
        public static void SerializeData()
        {
            StudentDAL.SerializeData();
        }
        public static void DeserializeData()
        {
            StudentDAL.DeserializeData();
        }
        

        public static Student SearchStudentBAL(int searchStudentID)
        {
            Student searchStudent = null;
            try
            {
                StudentDAL studentDAL = new StudentDAL();
                searchStudent = studentDAL.SearchStudentDAL(searchStudentID);
            }
            catch (StudentNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchStudent;

        }

        public static bool UpdateStudentBAL(Student updateStudent)
        {
            bool studentUpdated = false;
            try
            {
                if (ValidateStudent(updateStudent))
                {
                    StudentDAL studentDAL = new StudentDAL();
                    studentUpdated = studentDAL.UpdateStudentDAL(updateStudent);
                }
            }
            catch (StudentNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studentUpdated;
        }

        public static bool DeleteStudentBAL(int RollNo)
        {
            bool studentDeleted = false;
            try
            {
                if (RollNo > 0)
                {
                    StudentDAL studentDAL = new StudentDAL();
                    studentDeleted = studentDAL.DeleteStudentDAL(RollNo);
                }
                else
                {
                    throw new StudentNotFoundException("Invalid Student ID");
                }
            }
            catch (StudentNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studentDeleted;
        }
        //StudentDAL dal = new StudentDAL();
        //public void Add(Student stud)
        //{
        //    try
        //    {
        //        dal.Insert(stud);
        //    }
        //    catch(Exception ex)
        //    {
        //        throw;
        //    }
        //}

        //public List<Student> GetAll()
        //{
        //    return dal.SelectAll();
        //}
        //public static List<Student> GetAllStudentBL()
        //{
        //    List<Student> studentList = null;
        //    try
        //    {
        //        StudentDAL studentDAL = new StudentDAL();
        //        studentList = studentDAL.GetAllStudentDAL();
        //    }
        //    catch (StudentNotFoundException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return studentList;
        //}
    }
}
