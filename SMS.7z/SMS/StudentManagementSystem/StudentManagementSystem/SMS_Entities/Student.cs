﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entities
{
    [Serializable]
    public class Student
    {
        static int count;

        public Student()
        {
            count++;
            RollNo = count;
        }
        public int RollNo { get; set; }
        public string StudName { get; set; }
        public DateTime DOB { get; set; }
        public double FeesPaid { get; set; }
        public string MobileNo { get; set; }

    }
}
