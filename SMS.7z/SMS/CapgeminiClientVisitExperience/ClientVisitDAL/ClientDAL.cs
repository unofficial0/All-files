﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientVisitEntities;
using ClientVisit.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace ClientVisitDAL
{
    /// <summary>
    /// Client data access layer
    /// </summary>
    public class ClientDAL
    {
        public static List<Client> clientList = new List<Client>();

        /// <summary>
        /// method to add new client
        /// </summary>
        /// <param name="newClient"></param>
        /// <returns></returns>
        public bool AddClientDAL(Client newClient)
        {
            bool clientAdded = false;
            try
            {
                clientList.Add(newClient);
                clientAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ClientVisitException(ex.Message);
            }
            return clientAdded;
        }
        public List<Client> GetAllClientsDAL()
        {
            return clientList;
        }

        /// <summary>
        /// serialize data
        /// </summary>
        /// <param name="newClient"></param>
        /// <returns></returns>

        public bool SerializeDataDAL(Client newClient)

        {

            bool clientSerialized = false;

            try

            {

                clientList.Add(newClient);

                clientSerialized = true;

                FileStream fs = new FileStream("ClientDetails.dat", FileMode.Create);

                BinaryFormatter bff = new BinaryFormatter();

                bff.Serialize(fs, clientList);

                fs.Close();

            }

            catch (Exception ex)

            {

                throw new ClientVisit.Exceptions.ClientVisitException(ex.Message);

            }

            return clientSerialized;

        }

        /// <summary>
        /// deserialize data
        /// </summary>
        /// <returns></returns>

        public List<Client> DeserializeDataDAL()

        {

            //Reading file named "SalesDetails.dat"

            FileStream fs = new FileStream("ClientDetails.dat", FileMode.Open);

            BinaryFormatter bff = new BinaryFormatter();

            List<Client> clientList = bff.Deserialize(fs) as List<Client>;

            fs.Close();

            return clientList;

        }

    }

}



    
    

