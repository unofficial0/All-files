﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientVisitDAL;
using ClientVisitEntities;
using ClientVisit.Exceptions;

namespace ClientVisitBL
{/// <summary>
/// Client Business layer
/// </summary>
    public class ClientBL
    {
        /// <summary>
        /// class that validating the Client
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        private static bool ValidateClient(Client  client)
        {
            StringBuilder sb = new StringBuilder();
            bool validClient = true;
            
            if (client.ClientName == string.Empty)
            {
                validClient = false;
                sb.Append(Environment.NewLine + "Client Name Required");

            }
            if (client.VisitorName == string.Empty)
            {
                validClient = false;
                sb.Append(Environment.NewLine + "Vistor Name Required");

            }
            if (client.Industry == string.Empty)
            {
                validClient = false;
                sb.Append(Environment.NewLine + "Industry Name Required");

            }
            if (client.Bu.Equals("APPSNA")||client.Bu.Equals("APPSUK")||client.Bu.Equals("Sogeti"))
            {
                validClient = false;
                sb.Append(Environment.NewLine + " The BU should be from APPSNA, APPSUK, Sogeti");

            }
            if (client.FromDate < client.ToDate)
            {
                validClient = false;
                sb.Append(Environment.NewLine + "From date cannot be less than ToDate");

            }
            if (client.City.Equals("Mumbai")||client.City.Equals("Pune")||client.City.Equals("Banglore")||client.City.Equals("Chennai"))
            {
                validClient = false;
                sb.Append(Environment.NewLine + "City has to be mumbai,pune,Banglore and chennai");


            }

            if (validClient == false)
                throw new ClientVisitException(sb.ToString());
            return validClient;
        }
        /// <summary>
        ///method for Adding client into the list
        /// </summary>
        /// <param name="newClient"></param>
        /// <returns></returns>
        public static bool AddClientBL(Client newClient)
        {
            bool clientAdded = false;
            try
            {
                if (ValidateClient(newClient))
                {
                    ClientDAL clientDAL = new ClientDAL();
                    clientAdded = clientDAL.AddClientDAL(newClient);
                }
            }
            catch (ClientVisitException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return clientAdded;
        }
        /// <summary>
        /// Method to serialize the data
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public static bool SerializeDataBL(Client client)

        {

            bool clientSerialized = false;

            try

            {

                if (ValidateClient(client))

                {

                    ClientVisitDAL.ClientDAL clientDAL = new ClientVisitDAL.ClientDAL();

                    clientSerialized = clientDAL.SerializeDataDAL(client);

                }

            }

            catch (ClientVisit.Exceptions.ClientVisitException e)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return clientSerialized;

        }
        /// <summary>
        /// Deserialization method
        /// </summary>
        /// <returns></returns>

        public static List<Client> DeserializeDataBL()

        {

            List<Client> clientList = null;

            try

            {

                ClientVisitDAL.ClientDAL clientDAL = new ClientVisitDAL.ClientDAL();

                clientList = clientDAL.DeserializeDataDAL();

            }

            catch (ClientVisit.Exceptions.ClientVisitException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return clientList;

        }

    }

}

    
