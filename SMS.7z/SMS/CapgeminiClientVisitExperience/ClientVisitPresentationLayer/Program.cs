﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientVisit.Exceptions;
using ClientVisitBL;
using ClientVisitEntities;
/// <summary>
/// 
/// presentation layer of client
/// </summary>
namespace ClientVisitPresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddClient();
                        break;
                    case 2:
                        SerializeData();
                        break;
                    case 3:
                        DeserializeData();
                        break;
                    
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        /// <summary>
        /// Adding clent
        /// </summary>
            private static void AddClient()
            {
                try
                {
                    Client newClient = new Client();
                  
                    Console.WriteLine("Enter Client Name :");
                    newClient.ClientName = Console.ReadLine();

                    Console.WriteLine("Enter Visitor Name :");
                    newClient.VisitorName = Console.ReadLine();

                    Console.WriteLine("Enter Industry Name :");
                    newClient.Industry = Console.ReadLine();

                    Console.WriteLine("Enter BU :");
                    newClient.Bu = Console.ReadLine();

                    Console.WriteLine("Enter From Date :");
                    newClient.FromDate =Convert.ToDateTime( Console.ReadLine());

                    Console.WriteLine("Enter To Date :");
                    newClient.ToDate = Convert.ToDateTime(Console.ReadLine());

                    Console.WriteLine("Enter City :");
                    newClient.City = Console.ReadLine();

                    bool clientAdded = ClientBL.AddClientBL(newClient);
                    if (clientAdded)
                        Console.WriteLine("Client Added");
                    else
                        Console.WriteLine("Client not Added");
                }
                catch (ClientVisitException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        /// <summary>
        /// Perform serialization on the data
        /// </summary>

        private static void SerializeData()

        {

            try

            {

                Client newClient = new Client();

          

                Console.WriteLine("Enter Client Name :");

                newClient.ClientName = Console.ReadLine();

                Console.WriteLine("Enter visitor Name :");

                newClient.VisitorName = Console.ReadLine();

               

                Console.WriteLine("Enter Industry  :");

                newClient.Industry = Console.ReadLine();

                Console.WriteLine("Enter  BU (APPSNA,APPSUK,Sogeti):");

                newClient.Bu = Console.ReadLine();

                Console.WriteLine("Enter From Date :");
                newClient.FromDate = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter To Date :");
                newClient.ToDate = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter  City(mumbai,pune,banglore,chennai) :");

                newClient.City = Console.ReadLine();


                

                bool clientSerialized = ClientVisitBL.ClientBL.SerializeDataBL(newClient);

                if (clientSerialized)

                    Console.WriteLine("Client Serialized");

                else

                    Console.WriteLine("Client not Serialized");

            }

            catch (ClientVisit.Exceptions.ClientVisitException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }


        /// <summary>
        /// Perform Deserialization on the data
        /// </summary>

        private static void DeserializeData()

        {

            try

            {

                List<Client> clientList = ClientVisitBL.ClientBL.DeserializeDataBL();

                if (clientList != null && clientList.Count > 0)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("ClientName \t\tVisitorName \t\t Industry\t\tBU\t\tCity");

                    Console.WriteLine("******************************************************************************");

                    foreach (Client client in clientList)

                    {

                        Console.WriteLine("{0}\t\t\t{1}\t\t{2}\t\t{3}\t\t{4}", Client.ClientName , Client.VisitorName, Client.Industry,Client.Bu,Client.City);

                    }

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Serialized Data Available");

                }

            }

            catch (ClientVisit.Exceptions.ClientVisitException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }
        /// <summary>
        /// Client visiting menu
        /// </summary>
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Client Visit Menu***********");
            Console.WriteLine("1. Add Client");
            Console.WriteLine("2. List All Clients");

            Console.WriteLine("******************************************\n");

        }


    }

}




    

