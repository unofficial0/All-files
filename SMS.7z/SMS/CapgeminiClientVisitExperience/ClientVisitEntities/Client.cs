﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientVisitEntities
{
    /// <summary>
    /// serializable class
    /// </summary>
    [Serializable]
    public class Client
    {

        private string clientName;
        public string ClientName { get; set; }

        private string visitorName;
        public string VisitorName { get; set; }

        private string industry;
        public string Industry { get; set; }

        private string bu;
        public string Bu { get; set; }

        private DateTime fromDate;
        public DateTime FromDate { get; set; }

        private DateTime toDate;
        public DateTime ToDate { get; set; }

        private string city;
        public string City { get; set; }

        public Client()
        {
            clientName = string.Empty;
            visitorName = string.Empty;
            industry = string.Empty;
            bu = string.Empty;
            fromDate = default(DateTime);
            toDate = default(DateTime);
            city= string.Empty;
        }
    }
}
