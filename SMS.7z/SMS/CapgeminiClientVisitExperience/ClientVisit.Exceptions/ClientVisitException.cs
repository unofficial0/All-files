﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientVisit.Exceptions
{
    /// <summary>
    /// ClientVisitException class to handle exceptions
    /// </summary>
    public class ClientVisitException:ApplicationException
    {
        public ClientVisitException()
           : base()
        {
        }

        public ClientVisitException(string message)
            : base(message)
        {
        }
        public ClientVisitException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
