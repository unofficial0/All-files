﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_DAL;
using SMS_Entities;
using SMS_Exceptions;

namespace SMS_BAL
{
    public class StudentBAL
    {
       static StudentDAL dal = new StudentDAL();
// adding the student code
        public void Add(Student stud)
        {
           

                dal.Insert(stud);
           

        }
        // showing the student
        public List<Student> GetALL()
        {
            return dal.SelectAll();
        }
        //to update the student
        public  bool Update(Student student)
        {
            bool value = false;


            
            value =dal.Update(student);

            return value;
        }
        //to remove the student
        public  bool Remove(string studentName)
        {
            bool value = false;

            
            value = dal.Remove(studentname: studentName);

            return value;


        }
        
    }
}
