﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_BAL;
using SMS_Entities;
using SMS_Exceptions;
namespace SMS_PL
{
   public  class Program
    {

        static StudentBAL bal = new StudentBAL();
        public static void Main(string[] args)
        {
          
            int i;
            do
            {
                Console.WriteLine("===========menu=======");
                Console.WriteLine("1.Add Student");
                Console.WriteLine("2.update Student");
                Console.WriteLine("3.Remove student");
                Console.WriteLine("4.Display All Student details");
                Console.WriteLine("5.Exit");
                i = Convert.ToInt32(Console.ReadLine());
                switch (i)
                {
                    case 1:       add();
                                  break;
                    case 2:      Update();
                                 break;
                    case 3:
                                 Remove();
                                 break;
                    case 4:
                                Show();
                                break;

                }
            } while (i!=5);

            
            
        }
       public  static void Show()
        {
           

            var studs = bal.GetALL();
            foreach (var item in studs)
            {
                Console.WriteLine($"Rollno:{item.rollno}Name:{item.studname}");

            }

        }
        static void Remove()
        {
            Console.WriteLine("enter student name");
            string name = Console.ReadLine();
            bool Rem = bal.Remove(name);
            if (Rem == true)
            {
                Console.WriteLine("Removed succesfully");
            }
            else {

                Console.WriteLine("not removed");
            }



        }
       
        static void add()
        {
            

            // Student student1 = new Student();// { rollno = 101, studname = "yogesh",DOB="12-2-1997", };
            Student Addstudent = new Student();
            Console.WriteLine("  Name of the student :");
            Addstudent.studname = Console.ReadLine();
            Console.WriteLine("Add roll no :");
            Addstudent.rollno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Add date of birth");
            Addstudent.DOB = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("fees paid:");
            Addstudent.feespaid = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Add mobile number:");
            Addstudent.Mobileno = Console.ReadLine();
          
            bal.Add(Addstudent);
            
        }
        static void Update()
        {

            Student updatedstudent = new Student();
            Console.WriteLine("  Name of the student :");
            updatedstudent.studname= Console.ReadLine();
            Console.WriteLine("Update roll no :");
            updatedstudent.rollno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("update date of birth");
            updatedstudent.DOB = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("fees paid:");
            updatedstudent.feespaid = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Update mobile number:");
            updatedstudent.Mobileno = Console.ReadLine();
            bool studentUpdated =bal.Update(updatedstudent);
            if (studentUpdated)
                Console.WriteLine("Student Details Updated");
            else
                Console.WriteLine("Guest Details not Updated ");
        }
    }
}
