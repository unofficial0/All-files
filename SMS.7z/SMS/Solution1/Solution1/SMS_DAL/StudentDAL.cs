﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entities;
using SMS_Exceptions;
namespace SMS_DAL
{
    public class StudentDAL
    {
        List<Student> studs = new List<Student>();


        // adding the student code
        public void Insert(Student stud)
        {
            try
            {
                studs.Add(stud);
            }
            catch
            {
                throw;
            }
        }


        // showing the student
        public List<Student> SelectAll()
        {
            return studs;
        }

        //to remove the student
        public bool Remove(string studentname)
        {
            bool value = false;
            for (int i = 0; i < studs.Count; i++)
            {
               
                if (studs[i].studname == studentname)
                {
                    studs.Remove(studs[i]);
                    value = true;
                }
            }
            return value;
        }
        //to update the student
        //public void Delete(string name)
        //{
        //    //var student = studs.Find(s=>s.studname==name);
        //    //studs.Remove(s);
        //    //studs.Remove( studs.Find(s => s.studname == name));
        //    foreach (var s in studs)
        //    {
        //        if(s.studname==name)
        //        {

        //            studs.Remove(s);

        //        }
        //    }

        //}
        // Searching whether the name is present or not
        //public Student SearchName(string studName)
        //{

        //    int count;
        //        for(int i=0;i<studs.Count;i++)
        //        {
        //        if (studs[i].studname == studName)
        //        {

        //        }
        //        }
            
            
        //    return searchGuest;
        //}
        public bool Update(Student student)
        {
            //var studen = studs.Find(s => s.studname == student.studname);

            bool value = false;

            for (int i = 0; i < studs.Count; i++)
            {
                
                
                    if (studs[i].studname == student.studname)
                    {
                        studs[i].studname = student.studname;
                        studs[i].rollno = student.rollno;
                        studs[i].Mobileno = student.Mobileno;
                        studs[i].feespaid = student.feespaid;
                        studs[i].DOB = student.DOB;
                        value = true;
                    }
                
                
                
            }
            return value;

        }
        
}

    }

