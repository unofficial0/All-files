﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entities
{
    public class Student
    {
        static int count;

        public Student()
        {
            count++;
            rollno = count;
        }     
        public int rollno { get; set; }
        public string studname { get; set; }
        //validation
        //enter each and every element
        //it should not accept digits
        //it should be in 5 to 30 characters

        public DateTime DOB { get; set; }
        public double feespaid { get; set; }
        public string Mobileno { get; set; }

    }
}
