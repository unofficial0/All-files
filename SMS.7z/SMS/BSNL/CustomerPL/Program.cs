﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerEntity;
using CustomerException1;
using CustomerBL;

namespace CustomerPL
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintMenu();
        }
        private static void PrintMenu()
        {
            string choice1;
            do
            {
                Console.WriteLine("\n***********BSNL***********");
                Console.WriteLine("1. Add Connection");
                Console.WriteLine("3.Serialize data");
                Console.WriteLine("4.Deserailize data");

                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddConnection();
                        break;
                    case 3:
                        SerializeData();
                        break;
                    case 4:
                        DeserializeData();
                        break;

                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();
        }
        /// Method for adding Customer Details
        /// </summary>
        private static void AddConnection()
        {
            try
            {
                CustomerInfo newCustomer = new CustomerInfo();
                Console.WriteLine("Enter CustomerID :");
                newCustomer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter  CustomerName :");
                newCustomer.CustomerName = Console.ReadLine();

                Console.WriteLine("Enter CustomerDOB :");
                newCustomer.CustomerDOB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter PANnumber :");
                newCustomer.PANnumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter FacilitiesRequired :");
                newCustomer.FacilitiesRequired = Console.ReadLine();
                Console.WriteLine("Enter InitialPayment :");
                newCustomer.InitialPayment = Convert.ToInt32(Console.ReadLine());

                bool ConnectionAdded = CustomerBL.CustomersBL.AddConnectionBL(newCustomer);
                if (ConnectionAdded)
                    Console.WriteLine("Connection Added");
                else

                    Console.WriteLine("Connection not Added");
            }
            catch (CustomerException1.CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Method for writing List of Customers into file
        /// </summary>

        private static void SerializeData()
        {
            try
            {

                bool serializedata = CustomerBL.CustomersBL.SerializeBL();
                if (serializedata)
                    Console.WriteLine("Data Serialized");
                else
                    Console.WriteLine("Data not serialized");


            }
            catch (CustomerException1.CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Method for reading list from file and displaying
        /// </summary>
        private static void DeserializeData()
        {
            try
            {
                List<CustomerInfo> custList = CustomerBL.CustomersBL.DeserializeBL();
                if (custList != null && custList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("******************************************************************************");
                    foreach (CustomerInfo Customer in custList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t{4}\t{5}", Customer.CustomerId, Customer.CustomerName,
                                                Customer.CustomerDOB, Customer.PANnumber, Customer.FacilitiesRequired,
                                                Customer.InitialPayment);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (CustomerException1.CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

 }

