﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CustomerEntity;
using CustomerException1;
using CustomerDAL;


namespace CustomerBL
{
    public class CustomersBL
    {
        public static object CustomerDOB { get; private set; }

        /// <summary>
        /// Methods for Validating details of Customer
        /// and returning true or false
        /// </summary>
        /// <param name="Customer"> An object of CustomerEntity Class</param>
        private static bool ValidateCustomer(CustomerInfo Customer)
        {

            StringBuilder sb = new StringBuilder();
            bool validCustomer = true;
            if (Customer.PANnumber < 5)
            {
                sb.Append(Environment.NewLine + "Pan number should accept 5 alphabets followed by 3 digit and 1 alphabet");
            }
            if (String.IsNullOrEmpty(Customer.CustomerName))
                return false;

            if (String.IsNullOrEmpty(Customer.FacilitiesRequired))
                return false;


            if (!Regex.IsMatch((Customer.CustomerName).ToString(), @"^[a-zA-Z]+$"))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name Should be only alphabets and spaces");

            }
            if (Customer.Age = CustomerDOB.Subtract(DateTime.Now) < 18)

            {

                validCustomer = false;

                sb.Append(Environment.NewLine + "specified age should be less than 18 years");

            }

            if (Customer.InitialPayment < 500)
            {
                sb.Append(Environment.NewLine + "InitialPayment must be more than 500");
            }

            if (Customer.FacilitiesRequired != "Broadband" || Customer.FacilitiesRequired != "STD" || Customer.FacilitiesRequired != "ISD")
            {
                sb.Append(Environment.NewLine + "Enter Correct facilities");
            }
            if (validCustomer == false)
                throw new CustomerException1.CustomerException(sb.ToString());
            return validCustomer;
        }
        
        public bool AddConnectionBL(CustomerInfo newCustomer)
        {
            bool connectionAdded = false;
            try
            {
                if (ValidateCustomer(newCustomer))
                {
                    CustomerDAL.CustomerDAL CustomerDAL = new CustomerDAL.CustomerDAL();
                    connectionAdded = CustomerDAL.AddConnectionDAL(newCustomer);
                }
            }
            catch (CustomerException1.CustomerException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return connectionAdded;
        }
        /// <summary>
        /// Methods for Writing customers records from customerList list to file
        /// Return true or false whether data is serialized or not respectively
        /// </summary>
        public bool SerializeBL()
        {
            bool serializedata = false;
            try
            {

                CustomerDAL.CustomerDAL CustomerDAL = new CustomerDAL.CustomerDAL();
                serializedata = CustomerDAL.SerializeDAL();

            }
            catch (CustomerException1.CustomerException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return serializedata;
        }

        /// <summary>
        /// Methods for reading customer details from file
        /// Return list of customer to caller function in Presentation layer
        /// Return true or false whether data is serialized or not respectively
        /// </summary>
        List<CustomerInfo> DeserializeBL()
        {
            List<CustomerInfo> customerList = null;
            try
            {
                CustomerDAL.CustomerDAL CustomerDAL = new CustomerDAL.CustomerDAL();
                customerList = CustomerDAL.DeserializeDAL();
            }
            catch (CustomerException1.CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

    }
}
    


