﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using CustomerEntity;
using CustomerException1;


namespace CustomerDAL
{
    public class CustomerDAL
    {
        //Declaring list as collection for storing details of Customer
        static List<CustomerInfo> customerList = new List<CustomerInfo>();

        /// <summary>
        /// Methods for adding Customer records in CustomerList list
        /// </summary>
        /// <param name="newCustomer"> An object of CustomerEntity Class</param>       
        public bool AddConnectionDAL(CustomerInfo newCustomer)
        {
            bool connectionAdded = false;
            try
            {
                customerList.Add(newCustomer);
                connectionAdded = true;
            }
            catch (Exception ex)
            {
                throw new CustomerException1.CustomerException(ex.Message);
            }
            return connectionAdded;
        }
        /// <summary>
        /// Methods for Writing customers records from customerList list in file
        /// </summary>
        public bool SerializeDAL()
        {
            bool dataSerialized = false;
            try
            {
                FileStream fileStream = new FileStream("ConnectionData.txt", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, customerList);
                fileStream.Close();
                dataSerialized = true;
            }
            catch (Exception ex)
            {
                throw new CustomerException1.CustomerException(ex.Message);
            }
            return dataSerialized;
        }
        /// <summary>
        /// Methods for Reading customer records from file and returning list to caller 
        /// function
        /// </summary>
        public List<CustomerInfo> DeserializeDAL()
        {

            List<CustomerInfo> RetrievedStudents;
            try
            {
                FileStream fileStream1 =
                 new FileStream("ConnectionData.txt", FileMode.Open);
                BinaryFormatter binaryFormatter1 = new BinaryFormatter();
                RetrievedStudents = (List<CustomerInfo>)binaryFormatter1.Deserialize(fileStream1);
                fileStream1.Close();

            }
            catch (Exception ex)
            {
                throw new CustomerException1.CustomerException(ex.Message);
            }
            return RetrievedStudents;
        }

        /// <summary>
        /// Methods for Displaying records from CustomerList list
        /// </summary>
        public List<CustomerInfo> GetAllCustomersDAL()
        {
            return customerList;
        }


    }
}

