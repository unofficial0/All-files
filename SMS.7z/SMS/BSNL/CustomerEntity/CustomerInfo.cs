﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerEntity
{
    [Serializable]
    public class CustomerInfo
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime CustomerDOB { get; set; }
        public TimeSpan Age { get; set; }
        public int PANnumber { get; set; }
        public string FacilitiesRequired { get; set; }
        public int InitialPayment { get; set; }

    }
}
