﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using PatientEntity;
using PatientDAL;

namespace PatientBLL
{
    public class PatientBLL
    {

        private static bool ValidatePatient(Patient patient)
        {

            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientID <= 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Invalid Patient ID");

            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Name Required");

            }
            if (patient.Phone.Length < 10)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validPatient == false)
                throw new HMSException.HMSException(sb.ToString());
            return validPatient;
        }

        public static bool AddPatientBL(Patient newPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    patientAdded = patientDAL.AddPatientDAL(newPatient);
                }
            }
            catch (HMSException.HMSException e)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientAdded;
        }

        public static List<Patient> GetAllPatientsBL()
        {
            List<Patient> patientList = null;
            try
            {
                PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                patientList = patientDAL.GetAllPatientsDAL();
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }




        public static bool DeletePatientBL(int deletePatientID)
        {
            bool patientDeleted = false;
            try
            {
                if (deletePatientID > 0)
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    patientDeleted = patientDAL.DeletePatientDAL(deletePatientID);
                }
                else
                {
                    throw new HMSException.HMSException("Invalid Patient ID");
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientDeleted;
        }

        public static Patient SearchPatientBL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                searchPatient = patientDAL.SearchPatientDAL(searchPatientID);
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static bool UpdatePatientBL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    patientUpdated = patientDAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }


    }
}
