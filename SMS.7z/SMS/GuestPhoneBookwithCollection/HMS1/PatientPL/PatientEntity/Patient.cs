﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PatientEntity
{       
       
      [Gender("wejqjl")] 
    public class Patient
    {
        public int PatientID { get; set; }
        public string PatientName { get; set; }
        public string Phone { get; set; }
    }
     [AttributeUsage(AttributeTargets.Class, AllowMultiple =false)]
    public class GenderAttribute : Attribute
    {
         private string gender;
        public string  Gender { 
            
            get{
                return gender;
                }
            set {

                if (value=="male" || value=="female")
                {
                    gender = "gender type=\t"+value;
                }
                else
                {
                    gender = "invalid gender type\t" + value;
                    
                }
               
                
                }
        }
        public GenderAttribute()
        { }

        public GenderAttribute(string gender)
        {
            this.Gender = gender;
            
            
        }
       
    
    }
    
}
