﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.BLL;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.PL
{
    class Program
    {
        public static void GetAllSupplier()
        {
            try
            {
                List<Supplier> slist = SupplierBLL.GetAllSupplierBLL();

                if (slist != null)
                {
                    Console.WriteLine("ID\tName\tContact\tCity");
                    Console.WriteLine("-------------------------------------");

                    foreach (Supplier s in slist)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}\t{3}",
                            s.ID,s.Name,s.Contact,s.City);
                    }
                }
            }
            catch (SupplierException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void AddSuplier()
        {
            try
            {
                Supplier supplier = new Supplier();

                Console.WriteLine("Enter Supplier ID");
                supplier.ID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Supplier Name");
                supplier.Name = Console.ReadLine();

                Console.WriteLine("Enter Supplier Contact");
                supplier.Contact = Console.ReadLine();

                Console.WriteLine("Enter Supplier City");
                supplier.City = Console.ReadLine();

                if (SupplierBLL.AddSupplierBLL(supplier))
                {
                    Console.WriteLine("Supplier details added successfully");
                }
                else
                {
                    Console.WriteLine("Unable to Add Supplier");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("*************Supplier Management System**************");
            Console.WriteLine("1.Add Supplier");
            Console.WriteLine("2.Display All Supplier");
            Console.WriteLine("3.Exit");
            Console.WriteLine("*****************************************************");
        }
        static void Main(string[] args)
        {
            int choice;

            while (true)
            {
                PrintMenu();
                Console.WriteLine("Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddSuplier();
                        break;

                    case 2:
                        GetAllSupplier();
                        break;

                    case 3:
                        return;
                        break;

                    default:
                        Console.WriteLine("Invalid Entry Try Again");
                        break;

                }
            }
        }
    }
}
