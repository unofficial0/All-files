﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class SupplierDAL
    {
        //declare a list collection object
        private static List<Supplier> slist = new List<Supplier>();

        /// <summary>
        /// Get Alls the Supplier Information
        /// </summary>
        /// <returns></returns>
        public List<Supplier> GetAllSupplierDAL()
        {
            return slist;
        }

        /// <summary>
        /// Adds Supplier into the Collection
        /// </summary>
        /// <param name="sup">Supplier Object</param>
        /// <returns></returns>
        public bool AddSupplierDAL(Supplier sup)
        {
            bool supplierAdded = false;
            try
            {
                slist.Add(sup);
                supplierAdded = true;
            }
            catch (Exception ex)
            {
                throw new 
                    SupplierException("Unable to Add Supplier details");
            }
            return supplierAdded;
        }
    }
}
