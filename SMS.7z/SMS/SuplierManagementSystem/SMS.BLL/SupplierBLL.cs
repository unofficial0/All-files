﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SMS.DAL;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.BLL
{
    public class SupplierBLL
    {
        private static bool Validate(Supplier sup)
        {
            StringBuilder sb = new StringBuilder();
            bool validSupplier = true;

            if (sup.ID <= 0)
            {
                validSupplier = false;
                sb.Append("\nSupplier cannot be negative or zero");
            }

            if (sup.Name == string.Empty)
            {
                validSupplier = false;
                sb.Append("\nSupplier Name Cannot be blank");
            }

            if (sup.Contact == string.Empty)
            {
                validSupplier = false;
                sb.Append("\nContact cannot be blank");
            }

            if (sup.Contact.Length < 10 || sup.Contact.Length > 10)
            {
                validSupplier = false;
                sb.Append("\nContact number should be of 10 digits");
            }

            if (sup.City == string.Empty)
            {
                validSupplier = false;
                sb.Append("\nCity name cannot be blank");
            }

            if (validSupplier == false)
                throw new SupplierException(sb.ToString());

            return validSupplier;
        }

        public static List<Supplier> GetAllSupplierBLL()
        {
            List<Supplier> slist = null;
            try
            {
                SupplierDAL objDAL = new SupplierDAL();
                slist = objDAL.GetAllSupplierDAL();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return slist;
        }

        public static bool AddSupplierBLL(Supplier supplier)
        {
            bool supplierAdded = false;

            try
            {
                if (Validate(supplier))
                {
                    SupplierDAL objDAL = new SupplierDAL();
                    supplierAdded = objDAL.AddSupplierDAL(supplier);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return supplierAdded;
        }
    }
}
